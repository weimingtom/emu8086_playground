package emu8080_java;

public class InstructionArray {
	public int value;
	public String str;
	
	public InstructionArray(int value, String str) {
		this.value = value;
		this.str = str;
	}

	public InstructionArray(String str, int value) {
		this.value = value;
		this.str = str;
	}
}
