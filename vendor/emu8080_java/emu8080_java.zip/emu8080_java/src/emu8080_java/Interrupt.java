package emu8080_java;

public interface Interrupt {
	public void apply(Cpu this_, int[] data);
}
