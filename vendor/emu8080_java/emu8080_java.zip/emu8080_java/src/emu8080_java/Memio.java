package emu8080_java;

import java.util.List;

public class Memio {
	// Copyright Stefan Tramm, 2010
	//
	// Redistribution and use in source and binary forms, with or without
	// modification, are permitted provided that the following conditions are met:
	//
	// 1. Redistributions of source code must retain the above copyright notice,
	//	    this list of conditions and the following disclaimer.
	//
	// 2. Redistributions in binary form must reproduce the above copyright notice,
	//	    this list of conditions and the following disclaimer in the documentation
	//	    and/or other materials provided with the distribution.
	//
	// THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES,
	// INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
	// FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
	// DEVELOPERS AND CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
	// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
	// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
	// OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
	// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
	// OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
	// ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	//

	public static String pad(String str, int n) {
		StringBuffer r = new StringBuffer();
		for (int i=0; i < (n - str.length()); ++i)
			r.append("0");
		r.append(str);
		return r.toString();
	}
	
	public byte[] ram;
	
	public byte rd(int a) {
		return this.ram[a];
	}
	
	public void output(int port, int value) {
	}
	
	public int input(int port) {
		return 0;
	}
	
	public byte wr(int a, byte b) {
		this.ram[a & 0xffff] = (byte)(b & 0xff);
		return b;
	}
}
