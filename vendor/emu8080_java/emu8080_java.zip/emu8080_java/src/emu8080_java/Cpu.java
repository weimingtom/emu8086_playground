package emu8080_java;

public class Cpu {
	// js8080 original by Chris Double (http://www.bluishcoder.co.nz/js8080/)
	// modified by Stefan Tramm, 2010
	//
	// Redistribution and use in source and binary forms, with or without
	// modification, are permitted provided that the following conditions are
	// met:
	//
	// 1. Redistributions of source code must retain the above copyright notice,
	// this list of conditions and the following disclaimer.
	//
	// 2. Redistributions in binary form must reproduce the above copyright
	// notice,
	// this list of conditions and the following disclaimer in the documentation
	// and/or other materials provided with the distribution.
	//
	// THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESS OR IMPLIED
	// WARRANTIES,
	// INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
	// AND
	// FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
	// DEVELOPERS AND CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
	// INCIDENTAL,
	// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
	// TO,
	// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
	// PROFITS;
	// OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
	// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
	// OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
	// ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
	//
	private final static int CARRY = 0x01;
	private final static int PARITY = 0x04;
	private final static int HALFCARRY = 0x10;
	private final static int INTERRUPT = 0x20;
	private final static int ZERO = 0x40;
	private final static int SIGN = 0x80;

	private int b, c, d, e, f, h, l, a, pc, sp;
	private Memio memio;
	private byte[] ram;
	private Interrupt interrupt;
	private int lastInterrupt, cycles;

	public Cpu(Memio memio, Interrupt interrupt) {
		this.b = 0;
		this.c = 0;
		this.d = 0;
		this.e = 0;
		this.f = 0;
		this.h = 0;
		this.l = 0;
		this.a = 0;
		this.pc = 0;
		this.sp = 0xF000; // TBD
		this.memio = memio;
		this.ram = memio.ram; // should only be used by the disass
		this.lastInterrupt = 0x10;
		this.cycles = 0;
		this.interrupt = interrupt;
	}

	public int af() {
		return this.a << 8 | this.f;
	}

	public void AF(int n) {
		this.a = n >> 8 & 0xFF;
		this.f = n & 0xFF;
	}

	public int bc() {
		return this.b << 8 | this.c;
	}

	public void BC(int n) {
		this.b = n >> 8 & 0xFF;
		this.c = n & 0xFF;
	}

	public int de() {
		return this.d << 8 | this.e;
	}

	public void DE(int n) {
		this.d = n >> 8 & 0xFF;
		this.e = n & 0xFF;
	}

	public int hl() {
		return this.h << 8 | this.l;
	}

	public void HL(int n) {
		this.h = n >> 8 & 0xFF;
		this.l = n & 0xFF;
	}

	public void set(int flag) {
		this.f |= flag;
	}

	public void clear(int flag) {
		this.f &= ~flag & 0xFF;
	}

	@Override
	public String toString() {
		return "{" + " af: " + Memio.pad(Integer.toString(this.af(), 16), 4)
				+ " bc: " + Memio.pad(Integer.toString(this.bc(), 16), 4)
				+ " de: " + Memio.pad(Integer.toString(this.de(), 16), 4)
				+ " hl: " + Memio.pad(Integer.toString(this.hl(), 16), 4)
				+ " pc: " + Memio.pad(Integer.toString(this.pc, 16), 4)
				+ " sp: " + Memio.pad(Integer.toString(this.sp, 16), 4)
				+ " flags: " + ((this.f & ZERO) != 0 ? "z" : ".")
				+ ((this.f & SIGN) != 0 ? "s" : ".")
				+ ((this.f & PARITY) != 0 ? "p" : ".")
				+ ((this.f & CARRY) != 0 ? "c" : ".") + " "
				+ this.disassemble1(this.pc).str + " }";
	}

	public String cpuStatus() {
		String s = "";
		s += " AF:" + Memio.pad(Integer.toString(this.af(), 16), 4);
		s += " " + ((this.f & SIGN) != 0 ? "s" : ".")
				+ ((this.f & ZERO) != 0 ? "z" : ".")
				+ ((this.f & INTERRUPT) != 0 ? "I" : ".")
				+ ((this.f & HALFCARRY) != 0 ? "h" : ".")
				+ ((this.f & PARITY) != 0 ? "p" : ".")
				+ ((this.f & CARRY) != 0 ? "c" : ".");
		s += " BC:" + Memio.pad(Integer.toString(this.bc(), 16), 4);
		s += " DE:" + Memio.pad(Integer.toString(this.de(), 16), 4);
		s += " HL:" + Memio.pad(Integer.toString(this.hl(), 16), 4);
		s += " (HL):"
				+ Memio.pad(Integer.toString(this.memio.rd(this.hl()), 16), 2);
		s += " SP:" + Memio.pad(Integer.toString(this.sp, 16), 4);
		s += " PC:"; // +pad(this.pc.toString(16),4);
		s += this.disassemble1(this.pc).str;
		// s += " [" + this.cycles + "]";
		return s;
	}

	// Step through one instruction
	public boolean step() {
		byte i = this.memio.rd(this.pc++);
		this.pc &= 0xFFFF;
		boolean r = this.execute(i);
		this.processInterrupts();
		return r;
	}

	public Cpu writePort(int port, int v) {
		this.memio.output(port, v);
		return this;
	}

	public int readPort(int port) {
		return this.memio.input(port);
	}

	public int getByte(int addr) {
		return this.memio.rd(addr);
	}

	public int getWord(int addr) {
		byte l = this.memio.rd(addr);
		byte h = this.memio.rd(addr + 1);
		return h << 8 | l;
	}

	public int nextByte() {
		byte b = this.memio.rd(this.pc++);
		this.pc &= 0xFFFF;
		return b;
	}

	public int nextWord() {
		int pc = this.pc;
		byte l = this.memio.rd(pc++);
		byte h = this.memio.rd(pc++);
		this.pc = pc & 0xFFFF;
		return h << 8 | l;
	}

	public Cpu writeByte(int addr, int value) {
		byte v = (byte) (value & 0xFF);
		this.memio.wr(addr, v);
		return this;
	}

	public Cpu writeWord(int addr, int value) {
		int l = value;
		int h = value >> 8;
		this.writeByte(addr, l);
		this.writeByte(addr + 1, h);
		return this;
	}

	// use this for address arithmetic
	public int add(int a, int b) {
		return (a + b) & 0xffff;
	}

	// set flags after arithmetic and logical ops
	public int calcFlags(int v, int lhs, int rhs) {
		int x = v & 0xFF;

		// calc parity (see Henry S. Warren "Hackers Delight", page 74)
		int y = x ^ (x >> 1);
		y ^= y >> 2;
		y ^= y >> 4;

		if ((y & 1) != 0)
			this.f &= ~PARITY & 0xFF; // PO
		else
			this.f |= PARITY; // PE

		if ((v & 0x80) != 0)
			this.f |= SIGN;
		else
			this.f &= ~SIGN & 0xFF;

		if (x != 0)
			this.f &= ~ZERO & 0xFF;
		else
			this.f |= ZERO;

		if ((((rhs ^ v) ^ lhs) & 0x10) != 0)
			this.f |= HALFCARRY;
		else
			this.f &= ~HALFCARRY & 0xFF;

		if (v >= 0x100 || v < 0)
			this.f |= CARRY;
		else
			this.f &= ~CARRY & 0xFF;

		return x;
	}

	public int incrementByte(int o) {
		int c = this.f & CARRY; // carry isnt affected
		int r = this.calcFlags(o + 1, o, 1);
		this.f = (this.f & ~CARRY & 0xFF) | c;
		return r;
	}

	public int decrementByte(int o) {
		int c = this.f & CARRY; // carry isnt affected
		int r = this.calcFlags(o - 1, o, 1);
		this.f = (this.f & ~CARRY & 0xFF) | c;
		return r;
	}

	public int addByte(int lhs, int rhs) {
		return this.calcFlags(lhs + rhs, lhs, rhs);
	}

	public int addByteWithCarry(int lhs, int rhs) {
		return this.addByte(lhs, rhs + ((this.f & CARRY) != 0 ? 1 : 0));
	}

	public int subtractByte(int lhs, int rhs) {
		return this.calcFlags(lhs - rhs, lhs, rhs);
	}

	public int subtractByteWithCarry(int lhs, int rhs) {
		return this.subtractByte(lhs, rhs + ((this.f & CARRY) != 0 ? 1 : 0));
	}

	public int andByte(int lhs, int rhs) {
		int x = this.calcFlags(lhs & rhs, lhs, rhs);
		this.f |= HALFCARRY;
		this.f &= ~CARRY & 0xFF;
		return x;
	}

	public int xorByte(int lhs, int rhs) {
		int x = this.calcFlags(lhs ^ rhs, lhs, rhs);
		this.f |= HALFCARRY;
		this.f &= ~CARRY & 0xFF;
		return x;
	}

	public int orByte(int lhs, int rhs) {
		int x = this.calcFlags(lhs | rhs, lhs, rhs);
		this.f |= HALFCARRY;
		this.f &= ~CARRY & 0xFF;
		return x;
	}

	public int addWord(int lhs, int rhs) {
		int r = lhs + rhs;
		if (r > 0xFFFF)
			this.f |= CARRY;
		else
			this.f &= ~CARRY & 0xFF;
		return r & 0xFFFF;
	}

	public int pop() {
		int pc = this.getWord(this.sp);
		this.sp = (this.sp + 2) & 0xFFFF;
		return pc;
	}

	public void push(int v) {
		this.sp = (this.sp - 2) & 0xFFFF;
		this.writeWord(this.sp, v);
	}

	public void processInterrupts() {
		if (this.cycles < 1000000000)
			return;
		this.cycles -= 1000000000;
		return;

		// if (this.cycles < 16667)
		// return;
		//
		// this.cycles -= 16667;
		// this.lastInterrupt = 0x08;
		//
		// if ((this.f & INTERRUPT)!=0) {
		// this.push(this.pc);
		// this.pc = this.lastInterrupt;
		// if (this.interrupt != null)
		// this.interrupt.apply(this, new int[this.lastInterrupt]);
		// }
	}

	// returns false for HALT and illegal instr., else returns true
	public boolean execute(int i) {
		switch (i) {
		case 0x00: {
			// NOP
			this.cycles += 4;
		}
			break;

		case 0x01: {
			// LD BC,nn
			this.BC(this.nextWord());
			this.cycles += 10;
		}
			break;

		case 0x02: {
			// LD (BC),A
			this.writeByte(this.bc(), this.a);
			this.cycles += 7;
		}
			break;

		case 0x03: {
			// INC BC
			this.BC((this.bc() + 1) & 0xFFFF);
			this.cycles += 6;
		}
			break;

		case 0x04: {
			// INC B
			this.b = this.incrementByte(this.b);
			this.cycles += 5;
		}
			break;

		case 0x05: {
			// DEC B
			this.b = this.decrementByte(this.b);
			this.cycles += 5;
		}
			break;

		case 0x06: {
			// LD B,n
			this.b = this.nextByte();
			this.cycles += 7;
		}
			break;

		case 0x07: {
			// RLCA
			int l = (this.a & 0x80) >> 7;
			if (l != 0)
				this.f |= CARRY;
			else
				this.f &= ~CARRY & 0xFF;

			this.a = ((this.a << 1) & 0xFE) | l;
			this.cycles += 4;
		}
			break;

		case 0x09: {
			// ADD HL,BC
			this.HL(this.addWord(this.hl(), this.bc()));
			this.cycles += 11;
		}
			break;

		case 0x0A: {
			// LD A,(BC)
			this.a = this.memio.rd(this.bc());
			this.cycles += 7;
		}
			break;

		case 0x0B: {
			// DEC BC
			this.BC((this.bc() - 1) & 0xFFFF);
			this.cycles += 6;
		}
			break;

		case 0x0C: {
			// INC C
			this.c = this.incrementByte(this.c);
			this.cycles += 5;
		}
			break;

		case 0x0D: {
			// DEC C
			this.c = this.decrementByte(this.c);
			this.cycles += 5;
		}
			break;

		case 0x0E: {
			// LD C,n
			this.c = this.nextByte();
			this.cycles += 7;
		}
			break;

		case 0x0F: {
			// RRCA
			int h = (this.a & 1) << 7;
			if (h != 0)
				this.f |= CARRY;
			else
				this.f &= ~CARRY & 0xFF;

			this.a = ((this.a >> 1) & 0x7F) | h;
			this.cycles += 4;
		}
			break;

		case 0x11: {
			// LD DE,nn
			this.DE(this.nextWord());
			this.cycles += 10;
		}
			break;

		case 0x12: {
			// LD (DE),A
			this.writeByte(this.de(), this.a);
			this.cycles += 7;
		}
			break;

		case 0x13: {
			// INC DE
			this.DE((this.de() + 1) & 0xFFFF);
			this.cycles += 6;
		}
			break;

		case 0x14: {
			// INC D
			this.d = this.incrementByte(this.d);
			this.cycles += 5;
		}
			break;

		case 0x15: {
			// DEC D
			this.d = this.decrementByte(this.d);
			this.cycles += 5;
		}
			break;

		case 0x16: {
			// LD D,n
			this.d = this.nextByte();
			this.cycles += 7;
		}
			break;

		case 0x17: {
			// RLA
			int c = (this.f & CARRY) != 0 ? 1 : 0;
			if ((this.a & 0x80) != 0)
				this.f |= CARRY;
			else
				this.f &= ~CARRY & 0xFF;
			this.a = ((this.a << 1) & 0xFE) | c;
			this.cycles += 4;
		}
			break;

		case 0x19: {
			// ADD HL,DE
			this.HL(this.addWord(this.hl(), this.de()));
			this.cycles += 11;
		}
			break;

		case 0x1A: {
			// LD A,(DE)
			this.a = this.memio.rd(this.de());
			this.cycles += 7;
		}
			break;

		case 0x1B: {
			// DEC DE
			this.DE((this.de() - 1) & 0xFFFF);
			this.cycles += 6;
		}
			break;

		case 0x1C: {
			// INC E
			this.e = this.incrementByte(this.e);
			this.cycles += 5;
		}
			break;

		case 0x1D: {
			// DEC E
			this.e = this.decrementByte(this.e);
			this.cycles += 5;
		}
			break;

		case 0x1E: {
			// LD E,n
			this.e = this.nextByte();
			this.cycles += 7;
		}
			break;

		case 0x1F: {
			// RRA
			int c = (this.f & CARRY) != 0 ? 0x80 : 0;
			if ((this.a & 1) != 0)
				this.f |= CARRY;
			else
				this.f &= ~CARRY & 0xFF;
			this.a = ((this.a >> 1) & 0x7F) | c;
			this.cycles += 4;
		}
			break;

		case 0x21: {
			// LD HL,nn
			this.HL(this.nextWord());
			this.cycles += 10;
		}
			break;

		case 0x22: {
			// LD (nn),HL
			this.writeWord(this.nextWord(), this.hl());
			this.cycles += 16;
		}
			break;

		case 0x23: {
			// INC HL
			this.HL((this.hl() + 1) & 0xFFFF);
			this.cycles += 6;
		}
			break;

		case 0x24: {
			// INC H
			this.h = this.incrementByte(this.h);
			this.cycles += 5;
		}
			break;

		case 0x25: {
			// DEC H
			this.h = this.decrementByte(this.h);
			this.cycles += 5;
		}
			break;

		case 0x26: {
			// LD H,n
			this.h = this.nextByte();
			this.cycles += 7;
		}
			break;

		case 0x27: {
			// DAA
			int p1 = ((this.f & HALFCARRY) != 0 || (this.a & 0x0f) > 9) ? 6 : 0;
			this.a = this.calcFlags(this.a + p1, this.a, p1);
			int p3 = ((this.f & CARRY) != 0 || (this.a & 0xf0) > 0x90) ? 0x60
					: 0;
			this.a = this.calcFlags(this.a + p3, this.a, p3);
			this.cycles += 4;
		}
			break;

		case 0x29: {
			// ADD HL,HL
			this.HL(this.addWord(this.hl(), this.hl()));
			this.cycles += 11;
		}
			break;

		case 0x2A: {
			// LD HL,(nn)
			this.HL(this.getWord(this.nextWord()));
			this.cycles += 16;
		}
			break;

		case 0x2B: {
			// DEC HL
			this.HL((this.hl() - 1) & 0xFFFF);
			this.cycles += 6;
		}
			break;

		case 0x2C: {
			// INC L
			this.l = this.incrementByte(this.l);
			this.cycles += 5;
		}
			break;

		case 0x2D: {
			// DEC L
			this.l = this.decrementByte(this.l);
			this.cycles += 5;
		}
			break;

		case 0x2E: {
			// LD L,n
			this.l = this.nextByte();
			this.cycles += 7;
		}
			break;

		case 0x2F: {
			// CPL
			this.a ^= 0xFF;
			this.cycles += 4;
		}
			break;

		case 0x31: {
			// LD SP,nn
			this.sp = this.nextWord();
			this.cycles += 10;
		}
			break;

		case 0x32: {
			// LD (nn),A
			this.writeByte(this.nextWord(), this.a);
			this.cycles += 13;
		}
			break;

		case 0x33: {
			// INC SP
			this.sp = ((this.sp + 1) & 0xFFFF);
			this.cycles += 6;
		}
			break;

		case 0x34: {
			// INC (HL)
			int addr = this.hl();
			this.writeByte(addr, this.incrementByte(this.memio.rd(addr)));
			this.cycles += 10;
		}
			break;

		case 0x35: {
			// DEC (HL)
			int addr = this.hl();
			this.writeByte(addr, this.decrementByte(this.memio.rd(addr)));
			this.cycles += 10;
		}
			break;

		case 0x36: {
			// LD (HL),n
			this.writeByte(this.hl(), this.nextByte());
			this.cycles += 10;
		}
			break;

		case 0x37: {
			// SCF
			this.f |= CARRY;
			this.cycles += 4;
		}
			break;

		case 0x39: {
			// ADD HL,SP
			this.HL(this.addWord(this.hl(), this.sp));
			this.cycles += 11;
		}
			break;

		case 0x3A: {
			// LD A,(nn)
			this.a = this.memio.rd(this.nextWord());
			this.cycles += 13;
		}
			break;

		case 0x3B: {
			// DEC SP
			this.sp = (this.sp - 1) & 0xFFFF;
			this.cycles += 6;
		}
			break;

		case 0x3C: {
			// INC A
			this.a = this.incrementByte(this.a);
			this.cycles += 5;
		}
			break;

		case 0x3D: {
			// DEC A
			this.a = this.decrementByte(this.a);
			this.cycles += 5;
		}
			break;

		case 0x3E: {
			// LD A,n
			this.a = this.nextByte();
			this.cycles += 7;
		}
			break;

		case 0x3F: {
			// CCF
			this.f ^= CARRY; // ~CARRY & 0xFF;
			this.cycles += 4;
		}
			break;

		case 0x40: {
			// LD B,B
			this.b = this.b;
			this.cycles += 5;
		}
			break;

		case 0x41: {
			// LD B,C
			this.b = this.c;
			this.cycles += 5;
		}
			break;

		case 0x42: {
			// LD B,D
			this.b = this.d;
			this.cycles += 5;
		}
			break;

		case 0x43: {
			// LD B,E
			this.b = this.e;
			this.cycles += 5;
		}
			break;

		case 0x44: {
			// LD B,H
			this.b = this.h;
			this.cycles += 5;
		}
			break;

		case 0x45: {
			// LD B,L
			this.b = this.l;
			this.cycles += 5;
		}
			break;

		case 0x46: {
			// LD B,(HL)
			this.b = this.memio.rd(this.hl());
			this.cycles += 7;
		}
			break;

		case 0x47: {
			// LD B,A
			this.b = this.a;
			this.cycles += 5;
		}
			break;

		case 0x48: {
			// LD C,B
			this.c = this.b;
			this.cycles += 5;
		}
			break;

		case 0x49: {
			// LD C,C
			this.c = this.c;
			this.cycles += 5;
		}
			break;

		case 0x4A: {
			// LD C,D
			this.c = this.d;
			this.cycles += 5;
		}
			break;

		case 0x4B: {
			// LD C,E
			this.c = this.e;
			this.cycles += 5;
		}
			break;

		case 0x4C: {
			// LD C,H
			this.c = this.h;
			this.cycles += 5;
		}
			break;

		case 0x4D: {
			// LD C,L
			this.c = this.l;
			this.cycles += 5;
		}
			break;

		case 0x4E: {
			// LD C,(HL)
			this.c = this.memio.rd(this.hl());
			this.cycles += 7;
		}
			break;

		case 0x4F: {
			// LD C,A
			this.c = this.a;
			this.cycles += 5;
		}
			break;

		case 0x50: {
			// LD D,B
			this.d = this.b;
			this.cycles += 5;
		}
			break;

		case 0x51: {
			// LD D,C
			this.d = this.c;
			this.cycles += 5;
		}
			break;

		case 0x52: {
			// LD D,D
			this.d = this.d;
			this.cycles += 5;
		}
			break;

		case 0x53: {
			// LD D,E
			this.d = this.e;
			this.cycles += 5;
		}
			break;

		case 0x54: {
			// LD D,H
			this.d = this.h;
			this.cycles += 5;
		}
			break;

		case 0x55: {
			// LD D,L
			this.d = this.l;
			this.cycles += 5;
		}
			break;

		case 0x56: {
			// LD D,(HL)
			this.d = this.memio.rd(this.hl());
			this.cycles += 7;
		}
			break;

		case 0x57: {
			// LD D,A
			this.d = this.a;
			this.cycles += 5;
		}
			break;

		case 0x58: {
			// LD E,B
			this.e = this.b;
			this.cycles += 5;
		}
			break;

		case 0x59: {
			// LD E,C
			this.e = this.c;
			this.cycles += 5;
		}
			break;

		case 0x5A: {
			// LD E,D
			this.e = this.d;
			this.cycles += 5;
		}
			break;
		case 0x5B: {
			// LD E,E
			this.e = this.e;
			this.cycles += 5;
		}
			break;
		case 0x5C: {
			// LD E,H
			this.e = this.h;
			this.cycles += 5;
		}
			break;
		case 0x5D: {
			// LD E,L
			this.e = this.l;
			this.cycles += 5;
		}
			break;
		case 0x5E: {
			// LD E,(HL)
			this.e = this.memio.rd(this.hl());
			this.cycles += 7;
		}
			break;
		case 0x5F: {
			// LD E,A
			this.e = this.a;
			this.cycles += 5;
		}
			break;
		case 0x60: {
			// LD H,B
			this.h = this.b;
			this.cycles += 5;
		}
			break;
		case 0x61: {
			// LD H,C
			this.h = this.c;
			this.cycles += 5;
		}
			break;
		case 0x62: {
			// LD H,D
			this.h = this.d;
			this.cycles += 5;
		}
			break;
		case 0x63: {
			// LD H,E
			this.h = this.e;
			this.cycles += 5;
		}
			break;
		case 0x64: {
			// LD H,H
			this.h = this.h;
			this.cycles += 5;
		}
			break;
		case 0x65: {
			// LD H,L
			this.h = this.l;
			this.cycles += 5;
		}
			break;
		case 0x66: {
			// LD H,(HL)
			this.h = this.memio.rd(this.hl());
			this.cycles += 7;
		}
			break;
		case 0x67: {
			// LD H,A
			this.h = this.a;
			this.cycles += 5;
		}
			break;
		case 0x68: {
			// LD L,B
			this.l = this.b;
			this.cycles += 5;
		}
			break;
		case 0x69: {
			// LD L,C
			this.l = this.c;
			this.cycles += 5;
		}
			break;
		case 0x6A: {
			// LD L,D
			this.l = this.d;
			this.cycles += 5;
		}
			break;
		case 0x6B: {
			// LD L,E
			this.l = this.e;
			this.cycles += 5;
		}
			break;
		case 0x6C: {
			// LD L,H
			this.l = this.h;
			this.cycles += 5;
		}
			break;
		case 0x6D: {
			// LD L,L
			this.l = this.l;
			this.cycles += 5;
		}
			break;
		case 0x6E: {
			// LD L,(HL)
			this.l = this.memio.rd(this.hl());
			this.cycles += 7;
		}
			break;
		case 0x6F: {
			// LD L,A
			this.l = this.a;
			this.cycles += 5;
		}
			break;

		case 0x70: {
			// LD (HL),B
			this.writeByte(this.hl(), this.b);
			this.cycles += 7;
		}
			break;
		case 0x71: {
			// LD (HL),C
			this.writeByte(this.hl(), this.c);
			this.cycles += 7;
		}
			break;
		case 0x72: {
			// LD (HL),D
			this.writeByte(this.hl(), this.d);
			this.cycles += 7;
		}
			break;
		case 0x73: {
			// LD (HL),E
			this.writeByte(this.hl(), this.e);
			this.cycles += 7;
		}
			break;
		case 0x74: {
			// LD (HL),H
			this.writeByte(this.hl(), this.h);
			this.cycles += 7;
		}
			break;
		case 0x75: {
			// LD (HL),L
			this.writeByte(this.hl(), this.l);
			this.cycles += 7;
		}
			break;
		case 0x76: {
			// HALT
			this.cycles += 7;
			return false; // stop emulation
		}
		// break;

		case 0x77: {
			// LD (HL),A
			this.writeByte(this.hl(), this.a);
			this.cycles += 7;
		}
			break;
		case 0x78: {
			// LD A,B
			this.a = this.b;
			this.cycles += 5;
		}
			break;
		case 0x79: {
			// LD A,C
			this.a = this.c;
			this.cycles += 5;
		}
			break;
		case 0x7A: {
			// LD A,D
			this.a = this.d;
			this.cycles += 5;
		}
			break;
		case 0x7B: {
			// LD A,E
			this.a = this.e;
			this.cycles += 5;
		}
			break;
		case 0x7C: {
			// LD A,H
			this.a = this.h;
			this.cycles += 5;
		}
			break;
		case 0x7D: {
			// LD A,L
			this.a = this.l;
			this.cycles += 5;
		}
			break;
		case 0x7E: {
			// LD A,(HL)
			this.a = this.memio.rd(this.hl());
			this.cycles += 7;
		}
			break;
		case 0x7F: {
			// LD A,A
			this.a = this.a;
			this.cycles += 5;
		}
			break;
		case 0x80: {
			// ADD A,B
			this.a = this.addByte(this.a, this.b);
			this.cycles += 4;
		}
			break;
		case 0x81: {
			// ADD A,C
			this.a = this.addByte(this.a, this.c);
			this.cycles += 4;
		}
			break;
		case 0x82: {
			// ADD A,D
			this.a = this.addByte(this.a, this.d);
			this.cycles += 4;
		}
			break;
		case 0x83: {
			// ADD A,E
			this.a = this.addByte(this.a, this.e);
			this.cycles += 4;
		}
			break;
		case 0x84: {
			// ADD A,H
			this.a = this.addByte(this.a, this.h);
			this.cycles += 4;
		}
			break;
		case 0x85: {
			// ADD A,L
			this.a = this.addByte(this.a, this.l);
			this.cycles += 4;
		}
			break;
		case 0x86: {
			// ADD A,(HL)
			this.a = this.addByte(this.a, this.memio.rd(this.hl()));
			this.cycles += 7;
		}
			break;
		case 0x87: {
			// ADD A,A
			this.a = this.addByte(this.a, this.a);
			this.cycles += 4;
		}
			break;
		case 0x88: {
			// ADC A,B
			this.a = this.addByteWithCarry(this.a, this.b);
			this.cycles += 4;
		}
			break;
		case 0x89: {
			// ADC A,C
			this.a = this.addByteWithCarry(this.a, this.c);
			this.cycles += 4;
		}
			break;
		case 0x8A: {
			// ADC A,D
			this.a = this.addByteWithCarry(this.a, this.d);
			this.cycles += 4;
		}
			break;
		case 0x8B: {
			// ADC A,E
			this.a = this.addByteWithCarry(this.a, this.e);
			this.cycles += 4;
		}
			break;
		case 0x8C: {
			// ADC A,H
			this.a = this.addByteWithCarry(this.a, this.h);
			this.cycles += 4;
		}
			break;
		case 0x8D: {
			// ADC A,L
			this.a = this.addByteWithCarry(this.a, this.l);
			this.cycles += 4;
		}
			break;
		case 0x8E: {
			// ADC A,(HL)
			this.a = this.addByteWithCarry(this.a, this.memio.rd(this.hl()));
			this.cycles += 7;
		}
			break;
		case 0x8F: {
			// ADC A,A
			this.a = this.addByteWithCarry(this.a, this.a);
			this.cycles += 4;
		}
			break;
		case 0x90: {
			// SUB B
			this.a = this.subtractByte(this.a, this.b);
			this.cycles += 4;
		}
			break;
		case 0x91: {
			// SUB C
			this.a = this.subtractByte(this.a, this.c);
			this.cycles += 4;
		}
			break;
		case 0x92: {
			// SUB D
			this.a = this.subtractByte(this.a, this.d);
			this.cycles += 4;
		}
			break;
		case 0x93: {
			// SUB E
			this.a = this.subtractByte(this.a, this.e);
			this.cycles += 4;
		}
			break;
		case 0x94: {
			// SUB H
			this.a = this.subtractByte(this.a, this.h);
			this.cycles += 4;
		}
			break;
		case 0x95: {
			// SUB L
			this.a = this.subtractByte(this.a, this.l);
			this.cycles += 4;
		}
			break;
		case 0x96: {
			// SUB (HL)
			this.a = this.subtractByte(this.a, this.memio.rd(this.hl()));
			this.cycles += 7;
		}
			break;
		case 0x97: {
			// SUB A
			this.a = this.subtractByte(this.a, this.a);
			this.cycles += 4;
		}
			break;
		case 0x98: {
			// SBC A,B
			this.a = this.subtractByteWithCarry(this.a, this.b);
			this.cycles += 4;
		}
			break;
		case 0x99: {
			// SBC A,C
			this.a = this.subtractByteWithCarry(this.a, this.c);
			this.cycles += 4;
		}
			break;
		case 0x9A: {
			// SBC A,D
			this.a = this.subtractByteWithCarry(this.a, this.d);
			this.cycles += 4;
		}
			break;
		case 0x9B: {
			// SBC A,E
			this.a = this.subtractByteWithCarry(this.a, this.e);
			this.cycles += 4;
		}
			break;
		case 0x9C: {
			// SBC A,H
			this.a = this.subtractByteWithCarry(this.a, this.h);
			this.cycles += 4;
		}
			break;
		case 0x9D: {
			// SBC A,L
			this.a = this.subtractByteWithCarry(this.a, this.l);
			this.cycles += 4;
		}
			break;
		case 0x9E: {
			// SBC A,(HL)
			this.a = this.subtractByteWithCarry(this.a,
					this.memio.rd(this.hl()));
			this.cycles += 7;
		}
			break;
		case 0x9F: {
			// SBC A,A
			this.a = this.subtractByteWithCarry(this.a, this.a);
			this.cycles += 4;
		}
			break;
		case 0xA0: {
			// AND B
			this.a = this.andByte(this.a, this.b);
			this.cycles += 4;
		}
			break;
		case 0xA1: {
			// AND C
			this.a = this.andByte(this.a, this.c);
			this.cycles += 4;
		}
			break;
		case 0xA2: {
			// AND D
			this.a = this.andByte(this.a, this.d);
			this.cycles += 4;
		}
			break;
		case 0xA3: {
			// AND E
			this.a = this.andByte(this.a, this.e);
			this.cycles += 4;
		}
			break;
		case 0xA4: {
			// AND H
			this.a = this.andByte(this.a, this.h);
			this.cycles += 4;
		}
			break;
		case 0xA5: {
			// AND L
			this.a = this.andByte(this.a, this.l);
			this.cycles += 4;
		}
			break;
		case 0xA6: {
			// AND (HL)
			this.a = this.andByte(this.a, this.memio.rd(this.hl()));
			this.cycles += 7;
		}
			break;
		case 0xA7: {
			// AND A
			this.a = this.andByte(this.a, this.a);
			this.cycles += 4;
		}
			break;
		case 0xA8: {
			// XOR B
			this.a = this.xorByte(this.a, this.b);
			this.cycles += 4;
		}
			break;
		case 0xA9: {
			// XOR C
			this.a = this.xorByte(this.a, this.c);
			this.cycles += 4;
		}
			break;
		case 0xAA: {
			// XOR D
			this.a = this.xorByte(this.a, this.d);
			this.cycles += 4;
		}
			break;
		case 0xAB: {
			// XOR E
			this.a = this.xorByte(this.a, this.e);
			this.cycles += 4;
		}
			break;
		case 0xAC: {
			// XOR H
			this.a = this.xorByte(this.a, this.h);
			this.cycles += 4;
		}
			break;
		case 0xAD: {
			// XOR L
			this.a = this.xorByte(this.a, this.l);
			this.cycles += 4;
		}
			break;
		case 0xAE: {
			// XOR (HL)
			this.a = this.xorByte(this.a, this.memio.rd(this.hl()));
			this.cycles += 7;
		}
			break;
		case 0xAF: {
			// XOR A
			this.a = this.xorByte(this.a, this.a);
			this.cycles += 4;
		}
			break;
		case 0xB0: {
			// OR B
			this.a = this.orByte(this.a, this.b);
			this.cycles += 4;
		}
			break;
		case 0xB1: {
			// OR C
			this.a = this.orByte(this.a, this.c);
			this.cycles += 4;
		}
			break;
		case 0xB2: {
			// OR D
			this.a = this.orByte(this.a, this.d);
			this.cycles += 4;
		}
			break;
		case 0xB3: {
			// OR E
			this.a = this.orByte(this.a, this.e);
			this.cycles += 4;
		}
			break;
		case 0xB4: {
			// OR H
			this.a = this.orByte(this.a, this.h);
			this.cycles += 4;
		}
			break;
		case 0xB5: {
			// OR L
			this.a = this.orByte(this.a, this.l);
			this.cycles += 4;
		}
			break;
		case 0xB6: {
			// OR (HL)
			this.a = this.orByte(this.a, this.memio.rd(this.hl()));
			this.cycles += 7;
		}
			break;
		case 0xB7: {
			// OR A
			this.a = this.orByte(this.a, this.a);
			this.cycles += 4;
		}
			break;
		case 0xB8: {
			// CP B
			this.subtractByte(this.a, this.b);
			this.cycles += 4;
		}
			break;
		case 0xB9: {
			// CP C
			this.subtractByte(this.a, this.c);
			this.cycles += 4;
		}
			break;
		case 0xBA: {
			// CP D
			this.subtractByte(this.a, this.d);
			this.cycles += 4;
		}
			break;
		case 0xBB: {
			// CP E
			this.subtractByte(this.a, this.e);
			this.cycles += 4;
		}
			break;
		case 0xBC: {
			// CP H
			this.subtractByte(this.a, this.h);
			this.cycles += 4;
		}
			break;
		case 0xBD: {
			// CP L
			this.subtractByte(this.a, this.l);
			this.cycles += 4;
		}
			break;
		case 0xBE: {
			// CP (HL)
			this.subtractByte(this.a, this.memio.rd(this.hl()));
			this.cycles += 7;
		}
			break;
		case 0xBF: {
			// CP A
			this.subtractByte(this.a, this.a);
			this.cycles += 4;
		}
			break;
		case 0xC0: {
			// RET NZ ; opcode C0 cycles 05
			if ((this.f & ZERO) != 0)
				this.cycles += 5;
			else {
				this.pc = this.pop();
				this.cycles += 11;
			}
		}
			break;
		case 0xC1: {
			// POP BC
			this.BC(this.pop());
			this.cycles += 10;
		}
			break;
		case 0xC2: {
			// JP NZ,nn
			if ((this.f & ZERO) != 0) {
				this.pc = (this.pc + 2) & 0xFFFF;
			} else {
				this.pc = this.nextWord();
			}
			this.cycles += 10;
		}
			break;
		case 0xC3: {
			// JP nn
			this.pc = this.getWord(this.pc);
			this.cycles += 10;
		}
			break;
		case 0xC4: {
			// CALL NZ,nn
			if ((this.f & ZERO) != 0) {
				this.cycles += 11;
				this.pc = (this.pc + 2) & 0xFFFF;
			} else {
				this.cycles += 17;
				int w = this.nextWord();
				this.push(this.pc);
				this.pc = w;
			}
		}
			break;
		case 0xC5: {
			// PUSH BC
			this.push(this.bc());
			this.cycles += 11;
		}
			break;
		case 0xC6: {
			// ADD A,n
			this.a = this.addByte(this.a, this.nextByte());
			this.cycles += 7;
		}
			break;
		case 0xC7: {
			// RST 0
			this.push(this.pc);
			this.pc = 0;
			this.cycles += 11;
		}
			break;
		case 0xC8: {
			// RET Z
			if ((this.f & ZERO) != 0) {
				this.pc = this.pop();
				this.cycles += 11;
			} else {
				this.cycles += 5;
			}
		}
			break;
		case 0xC9: {
			// RET nn
			this.pc = this.pop();
			this.cycles += 10;
		}
			break;
		case 0xCA: {
			// JP Z,nn
			if ((this.f & ZERO) != 0) {
				this.pc = this.nextWord();
			} else {
				this.pc = (this.pc + 2) & 0xFFFF;
			}
			this.cycles += 10;
		}
			break;
		case 0xCC: {
			// CALL Z,nn
			if ((this.f & ZERO) != 0) {
				this.cycles += 17;
				int w = this.nextWord();
				this.push(this.pc);
				this.pc = w;
			} else {
				this.cycles += 11;
				this.pc = (this.pc + 2) & 0xFFFF;
			}
		}
			break;
		case 0xCD: {
			// CALL nn
			int w = this.nextWord();
			this.push(this.pc);
			this.pc = w;
			this.cycles += 17;
		}
			break;
		case 0xCE: {
			// ADC A,n
			this.a = this.addByteWithCarry(this.a, this.nextByte());
			this.cycles += 7;
		}
			break;
		case 0xCF: {
			// RST 8
			this.push(this.pc);
			this.pc = 0x08;
			this.cycles += 11;
		}
			break;
		case 0xD0: {
			// RET NC
			if ((this.f & CARRY) != 0) {
				this.cycles += 5;
			} else {
				this.pc = this.pop();
				this.cycles += 11;
			}
		}
			break;
		case 0xD1: {
			// POP DE
			this.DE(this.pop());
			this.cycles += 10;
		}
			break;
		case 0xD2: {
			// JP NC,nn
			if ((this.f & CARRY) != 0) {
				this.pc = (this.pc + 2) & 0xFFFF;
			} else {
				this.pc = this.nextWord();
			}
			this.cycles += 10;
		}
			break;
		case 0xD3: {
			// OUT (n),A
			this.writePort(this.nextByte(), this.a);
			this.cycles += 10;
		}
			break;
		case 0xD4: {
			// CALL NC,nn
			if ((this.f & CARRY) != 0) {
				this.cycles += 11;
				this.pc = (this.pc + 2) & 0xFFFF;
			} else {
				this.cycles += 17;
				int w = this.nextWord();
				this.push(this.pc);
				this.pc = w;
			}
		}
			break;
		case 0xD5: {
			// PUSH DE
			this.push(this.de());
			this.cycles += 11;
		}
			break;
		case 0xD6: {
			// SUB n
			this.a = this.subtractByte(this.a, this.nextByte());
			this.cycles += 7;
		}
			break;
		case 0xD7: {
			// RST 10H
			this.push(this.pc);
			this.pc = 0x10;
			this.cycles += 11;
		}
			break;
		case 0xD8: {
			// RET C
			if ((this.f & CARRY) != 0) {
				this.pc = this.pop();
				this.cycles += 11;
			} else {
				this.cycles += 5;
			}
		}
			break;
		case 0xDA: {
			// JP C,nn
			if ((this.f & CARRY) != 0) {
				this.pc = this.nextWord();
			} else {
				this.pc = (this.pc + 2) & 0xFFFF;
			}
			this.cycles += 10;
		}
			break;
		case 0xDB: {
			// IN A,(n)
			this.a = this.readPort(this.nextByte());
			this.cycles += 10;
		}
			break;
		case 0xDC: {
			// CALL C,nn
			if ((this.f & CARRY) != 0) {
				this.cycles += 17;
				int w = this.nextWord();
				this.push(this.pc);
				this.pc = w;
			} else {
				this.cycles += 11;
				this.pc = (this.pc + 2) & 0xFFFF;
			}
		}
			break;
		case 0xDE: {
			// SBC A,n
			this.a = this.subtractByteWithCarry(this.a, this.nextByte());
			this.cycles += 7;
		}
			break;
		case 0xDF: {
			// RST 18H
			this.push(this.pc);
			this.pc = 0x18;
			this.cycles += 11;
		}
			break;
		case 0xE0: {
			// RET PO
			if ((this.f & PARITY) != 0) {
				this.cycles += 5;
			} else {
				this.pc = this.pop();
				this.cycles += 11;
			}
		}
			break;
		case 0xE1: {
			// POP HL
			this.HL(this.pop());
			this.cycles += 10;
		}
			break;
		case 0xE2: {
			// JP PO,nn
			if ((this.f & PARITY) != 0) {
				this.pc = (this.pc + 2) & 0xFFFF;
			} else {
				this.pc = this.nextWord();
			}
			this.cycles += 10;
		}
			break;
		case 0xE3: {
			// EX (SP),HL ;
			int a = this.getWord(this.sp);
			this.writeWord(this.sp, this.hl());
			this.HL(a);
			this.cycles += 4;
		}
			break;
		case 0xE4: {
			// CALL PO,nn
			if ((this.f & PARITY) != 0) {
				this.cycles += 11;
				this.pc = (this.pc + 2) & 0xFFFF;
			} else {
				this.cycles += 17;
				int w = this.nextWord();
				this.push(this.pc);
				this.pc = w;
			}
		}
			break;
		case 0xE5: {
			// PUSH HL
			this.push(this.hl());
			this.cycles += 11;
		}
			break;
		case 0xE6: {
			// AND n
			this.a = this.andByte(this.a, this.nextByte());
			this.cycles += 7;
		}
			break;
		case 0xE7: {
			// RST 20H
			this.push(this.pc);
			this.pc = 0x20;
			this.cycles += 11;
		}
			break;
		case 0xE8: {
			// RET PE
			if ((this.f & PARITY) != 0) {
				this.pc = this.pop();
				this.cycles += 11;
			} else {
				this.cycles += 5;
			}
		}
			break;
		case 0xE9: {
			// JP (HL)
			this.pc = this.hl();
			this.cycles += 4;
		}
			break;
		case 0xEA: {
			// JP PE,nn
			if ((this.f & PARITY) != 0) {
				this.pc = this.nextWord();
			} else {
				this.pc = (this.pc + 2) & 0xFFFF;
			}
			this.cycles += 10;
		}
			break;
		case 0xEB: {
			// EX DE,HL
			int a = this.de();
			this.DE(this.hl());
			this.HL(a);
			this.cycles += 4;
		}
			break;
		case 0xEC: {
			// CALL PE,nn
			if ((this.f & PARITY) != 0) {
				this.cycles += 17;
				int w = this.nextWord();
				this.push(this.pc);
				this.pc = w;
			} else {
				this.cycles += 11;
				this.pc = (this.pc + 2) & 0xFFFF;
			}
		}
			break;
		case 0xEE: {
			// XOR n
			this.a = this.xorByte(this.a, this.nextByte());
			this.cycles += 7;
		}
			break;
		case 0xEF: {
			// RST 28H
			this.push(this.pc);
			this.pc = 0x28;
			this.cycles += 11;
		}
			break;
		case 0xF0: {
			// RET P
			if ((this.f & SIGN) != 0) {
				this.cycles += 5;
			} else {
				this.pc = this.pop();
				this.cycles += 11;
			}
		}
			break;
		case 0xF1: {
			// POP AF
			this.AF(this.pop());
			this.cycles += 10;
		}
			break;
		case 0xF2: {
			// JP P,nn
			if ((this.f & SIGN) != 0) {
				this.pc = (this.pc + 2) & 0xFFFF;
			} else {
				this.pc = this.nextWord();
			}
			this.cycles += 10;
		}
			break;
		case 0xF3: {
			// DI
			this.f &= ~INTERRUPT & 0xFF;
			this.cycles += 4;
		}
			break;
		case 0xF4: {
			// CALL P,nn
			if ((this.f & SIGN) != 0) {
				this.cycles += 11;
				this.pc = (this.pc + 2) & 0xFFFF;
			} else {
				this.cycles += 17;
				int w = this.nextWord();
				this.push(this.pc);
				this.pc = w;
			}
		}
			break;
		case 0xF5: {
			// PUSH AF
			this.push(this.af());
			this.cycles += 11;
		}
			break;
		case 0xF6: {
			// OR n
			this.a = this.orByte(this.a, this.nextByte());
			this.cycles += 7;
		}
			break;
		case 0xF7: {
			// RST 30H
			this.push(this.pc);
			this.pc = 0x30;
			this.cycles += 11;
		}
			break;
		case 0xF8: {
			// RET M
			if ((this.f & SIGN) != 0) {
				this.pc = this.pop();
				this.cycles += 11;
			} else {
				this.cycles += 5;
			}
		}
			break;
		case 0xF9: {
			// LD SP,HL
			this.sp = this.hl();
			this.cycles += 6;
		}
			break;
		case 0xFA: {
			// JP M,nn
			if ((this.f & SIGN) != 0) {
				this.pc = this.nextWord();
			} else {
				this.pc = (this.pc + 2) & 0xFFFF;
			}
			this.cycles += 10;
		}
			break;
		case 0xFB: {
			// EI
			this.f |= INTERRUPT;
			this.cycles += 4;
		}
			break;
		case 0xFC: {
			// CALL M,nn
			if ((this.f & SIGN) != 0) {
				this.cycles += 17;
				int w = this.nextWord();
				this.push(this.pc);
				this.pc = w;
			} else {
				this.cycles += 11;
				this.pc = (this.pc + 2) & 0xFFFF;
			}
		}
			break;
		case 0xFE: {
			// CP n
			this.subtractByte(this.a, this.nextByte());
			this.cycles += 7;
		}
			break;
		case 0xFF: {
			// RST 38H
			this.push(this.pc);
			this.pc = 0x38;
			this.cycles += 11;
		}
			break;
		default: {
			// illegal
			this.cycles += 4;
			return false; // illegal, stop execution
		}
		// break;
		}
		return true; // go-on
	}

	// disassembler accesses RAM directly
	// just for the case of memory mapped IO, not to trigger IO!
	public InstructionArray disassembleInstruction(int addr) {
		int i = (int) this.ram[addr];

		switch (i) {
		case 0x00: {
			// NOP
			String r = "NOP";
			return new InstructionArray(addr + 1, r);
		}
		// break;

		case 0x01: {
			// LD BC,nn
			String r = "LD BC," + Integer.toString(this.getWord(addr + 1), 16);
			return new InstructionArray(addr + 3, r);
		}
		// break;
		case 0x02: {
			// LD (BC),A
			String r = "LD (BC),A";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x03: {
			// INC BC
			String r = "INC BC";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x04: {
			// INC B
			String r = "INC B";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x05: {
			// DEC B
			String r = "DEC B";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x06: {
			// LD B,n
			String r = "LD B," + Integer.toString(this.ram[addr + 1], 16);
			return new InstructionArray(addr + 2, r);
		}
		// break;
		case 0x07: {
			// RLCA
			String r = "RLCA";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x09: {
			// ADD HL,BC
			String r = "ADD HL,BC";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x0A: {
			// LD A,(BC)
			String r = "LD A,(BC)";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x0B: {
			// DEC BC
			String r = "DEC BC";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x0C: {
			// INC C
			String r = "INC C";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x0D: {
			// DEC C
			String r = "DEC C";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x0E: {
			// LD C,n
			String r = "LD C," + Integer.toString(this.ram[addr + 1], 16);
			return new InstructionArray(addr + 2, r);
		}
		// break;
		case 0x0F: {
			// RRCA
			String r = "RRCA";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x11: {
			// LD DE,nn
			String r = "LD DE," + Integer.toString(this.getWord(addr + 1), 16);
			return new InstructionArray(addr + 3, r);
		}
		// break;
		case 0x12: {
			// LD (DE),A
			String r = "LD (DE),A";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x13: {
			// INC DE
			String r = "INC DE";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x14: {
			// INC D
			String r = "INC D";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x15: {
			// DEC D
			String r = "DEC D";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x16: {
			// LD D,n
			String r = "LD D," + Integer.toString(this.ram[addr + 1], 16);
			return new InstructionArray(addr + 2, r);
		}
		// break;
		case 0x17: {
			// RLA
			String r = "RLA";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x19: {
			// ADD HL,DE
			String r = "ADD HL,DE";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x1A: {
			// LD A,(DE)
			String r = "LD A,(DE)";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x1B: {
			// DEC DE
			String r = "DEC DE";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x1C: {
			// INC E
			String r = "INC E";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x1D: {
			// DEC E
			String r = "DEC E";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x1E: {
			// LD E,n
			String r = "LD E," + this.ram[addr + 1];
			return new InstructionArray(addr + 2, r);
		}
		// break;
		case 0x1F: {
			// RRA
			String r = "RRA";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x21: {
			// LD HL,nn
			String r = "LD HL," + Integer.toString(this.getWord(addr + 1), 16);
			return new InstructionArray(addr + 3, r);
		}
		// break;
		case 0x22: {
			// LD (nn),HL
			String r = "LD (" + Integer.toString(this.getWord(addr + 1), 16)
					+ "),HL";
			return new InstructionArray(addr + 3, r);
		}
		// break;
		case 0x23: {
			// INC HL
			String r = "INC HL";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x24: {
			// INC H
			String r = "INC H";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x25: {
			// DEC H
			String r = "DEC H";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x26: {
			// LD H,n
			String r = "LD H," + Integer.toString(this.ram[addr + 1], 16);
			return new InstructionArray(addr + 2, r);
		}
		// break;
		case 0x27: {
			// DAA
			String r = "DAA";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x29: {
			// ADD HL,HL
			String r = "ADD HL,HL";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x2A: {
			// LD HL,(nn)
			String r = "LD HL,(" + Integer.toString(this.getWord(addr + 1), 16)
					+ ")";
			return new InstructionArray(addr + 3, r);
		}
		// break;
		case 0x2B: {
			// DEC HL
			String r = "DEC HL";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x2C: {
			// INC L
			String r = "INC L";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x2D: {
			// DEC L
			String r = "DEC L";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x2E: {
			// LD L,n
			String r = "LD L," + Integer.toString(this.ram[addr + 1], 16);
			return new InstructionArray(addr + 2, r);
		}
		// break;
		case 0x2F: {
			// CPL
			String r = "CPL";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x31: {
			// LD SP,nn
			String r = "LD SP," + Integer.toString(this.getWord(addr + 1), 16);
			return new InstructionArray(addr + 3, r);
		}
		// break;
		case 0x32: {
			// LD (nn),A
			String r = "LD (" + Integer.toString(this.getWord(addr + 1), 16)
					+ "),A";
			return new InstructionArray(addr + 3, r);
		}
		// break;
		case 0x33: {
			// INC SP
			String r = "INC SP";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x34: {
			// INC (HL)
			String r = "INC (HL)";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x35: {
			// DEC (HL)
			String r = "DEC (HL)";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x36: {
			// LD (HL),n
			String r = "LD (HL)," + Integer.toString(this.ram[addr + 1], 16);
			return new InstructionArray(addr + 2, r);
		}
		// break;
		case 0x37: {
			// SCF
			String r = "SCF";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x39: {
			// ADD HL,SP
			String r = "ADD HL,SP";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x3A: {
			// LD A,(nn)
			String r = "LD A,(" + Integer.toString(this.getWord(addr + 1), 16)
					+ ")";
			return new InstructionArray(addr + 3, r);
		}
		// break;
		case 0x3B: {
			// DEC SP
			String r = "DEC SP";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x3C: {
			// INC A
			String r = "INC A";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x3D: {
			// DEC A
			String r = "DEC A";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x3E: {
			// LD A,n
			String r = "LD A," + Integer.toString(this.ram[addr + 1], 16);
			return new InstructionArray(addr + 2, r);
		}
		// break;
		case 0x3F: {
			// CCF
			String r = "CCF";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x40: {
			// LD B,B
			String r = "LD B,B";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x41: {
			// LD B,C
			String r = "LD B,C";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x42: {
			// LD B,D
			String r = "LD B,D";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x43: {
			// LD B,E
			String r = "LD B,E";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x44: {
			// LD B,H
			String r = "LD B,H";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x45: {
			// LD B,L
			String r = "LD B,L";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x46: {
			// LD B,(HL)
			String r = "LD B,(HL)";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x47: {
			// LD B,A
			String r = "LD B,A";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x48: {
			// LD C,B
			String r = "LD C,B";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x49: {
			// LD C,C
			String r = "LD C,C";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x4A: {
			// LD C,D
			String r = "LD C,D";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x4B: {
			// LD C,E
			String r = "LD C,E";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x4C: {
			// LD C,H
			String r = "LD C,H";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x4D: {
			// LD C,L
			String r = "LD C,L";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x4E: {
			// LD C,(HL)
			String r = "LD C,(HL)";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x4F: {
			// LD C,A
			String r = "LD C,A";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x50: {
			// LD D,B
			String r = "LD D,B";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x51: {
			// LD D,C
			String r = "LD D,C";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x52: {
			// LD D,D
			String r = "LD D,D";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x53: {
			// LD D,E
			String r = "LD D,E";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x54: {
			// LD D,H
			String r = "LD D,H";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x55: {
			// LD D,L
			String r = "LD D,L";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x56: {
			// LD D,(HL)
			String r = "LD D,(HL)";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x57: {
			// LD D,A
			String r = "LD D,A";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x58: {
			// LD E,B
			String r = "LD E,B";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x59: {
			// LD E,C
			String r = "LD E,C";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x5A: {
			// LD E,D
			String r = "LD E,D";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x5B: {
			// LD E,E
			String r = "LD E,E";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x5C: {
			// LD E,H
			String r = "LD E,H";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x5D: {
			// LD E,L
			String r = "LD E,L";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x5E: {
			// LD E,(HL)
			String r = "LD E,(HL)";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x5F: {
			// LD E,A
			String r = "LD E,A";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x60: {
			// LD H,B
			String r = "LD H,B";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x61: {
			// LD H,C
			String r = "LD H,C";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x62: {
			// LD H,D
			String r = "LD H,D";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x63: {
			// LD H,E
			String r = "LD H,E";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x64: {
			// LD H,H
			String r = "LD H,H";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x65: {
			// LD H,L
			String r = "LD H,L";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x66: {
			// LD H,(HL)
			String r = "LD H,(HL)";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x67: {
			// LD H,A
			String r = "LD H,A";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x68: {
			// LD L,B
			String r = "LD L,B";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x69: {
			// LD L,C
			String r = "LD L,C";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x6A: {
			// LD L,D
			String r = "LD L,D";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x6B: {
			// LD L,E
			String r = "LD L,E";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x6C: {
			// LD L,H
			String r = "LD L,H";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x6D: {
			// LD L,L
			String r = "LD L,L";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x6E: {
			// LD L,(HL)
			String r = "LD L,(HL)";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x6F: {
			// LD L,A
			String r = "LD L,A";
			return new InstructionArray(addr + 1, r);
		}
		// break;

		case 0x70: {
			// LD (HL),B
			String r = "LD (HL),B";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x71: {
			// LD (HL),C
			String r = "LD (HL),C";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x72: {
			// LD (HL),D
			String r = "LD (HL),D";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x73: {
			// LD (HL),E
			String r = "LD (HL),E";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x74: {
			// LD (HL),H
			String r = "LD (HL),H";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x75: {
			// LD (HL),L
			String r = "LD (HL),L";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x76: {
			// HALT
			String r = "HALT";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x77: {
			// LD (HL),A
			String r = "LD (HL),A";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x78: {
			// LD A,B
			String r = "LD A,B";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x79: {
			// LD A,C
			String r = "LD A,C";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x7A: {
			// LD A,D
			String r = "LD A,D";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x7B: {
			// LD A,E
			String r = "LD A,E";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x7C: {
			// LD A,H
			String r = "LD A,H";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x7D: {
			// LD A,L
			String r = "LD A,L";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x7E: {
			// LD A,(HL)
			String r = "LD A,(HL)";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x7F: {
			// LD A,A
			String r = "LD A,A";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x80: {
			// ADD A,B
			String r = "ADD A,B";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x81: {
			// ADD A,C
			String r = "ADD A,C";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x82: {
			// ADD A,D
			String r = "ADD A,D";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x83: {
			// ADD A,E
			String r = "ADD A,E";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x84: {
			// ADD A,H
			String r = "ADD A,H";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x85: {
			// ADD A,L
			String r = "ADD A,L";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x86: {
			// ADD A,(HL)
			String r = "ADD A,(HL)";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x87: {
			// ADD A,A
			String r = "ADD A,A";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x88: {
			// ADC A,B
			String r = "ADC A,B";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x89: {
			// ADC A,C
			String r = "ADC A,C";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x8A: {
			// ADC A,D
			String r = "ADC A,D";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x8B: {
			// ADC A,E
			String r = "ADC A,E";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x8C: {
			// ADC A,H
			String r = "ADC A,H";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x8D: {
			// ADC A,L
			String r = "ADC A,L";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x8E: {
			// ADC A,(HL)
			String r = "ADC A,(HL)";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x8F: {
			// ADC A,A
			String r = "ADC A,A";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x90: {
			// SUB B
			String r = "SUB B";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x91: {
			// SUB C
			String r = "SUB C";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x92: {
			// SUB D
			String r = "SUB D";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x93: {
			// SUB E
			String r = "SUB E";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x94: {
			// SUB H
			String r = "SUB H";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x95: {
			// SUB L
			String r = "SUB L";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x96: {
			// SUB (HL)
			String r = "SUB (HL)";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x97: {
			// SUB A
			String r = "SUB A";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x98: {
			// SBC A,B
			String r = "SBC A,B";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x99: {
			// SBC A,C
			String r = "ABC A,C";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x9A: {
			// SBC A,D
			String r = "SBC A,D";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x9B: {
			// SBC A,E
			String r = "SBC A,E";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x9C: {
			// SBC A,H
			String r = "SBC A,H";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x9D: {
			// SBC A,L
			String r = "SBC A,L";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x9E: {
			// SBC A,(HL)
			String r = "SBC A,(HL)";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0x9F: {
			// SBC A,A
			String r = "SBC A,A";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xA0: {
			// AND B
			String r = "AND B";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xA1: {
			// AND C
			String r = "AND C";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xA2: {
			// AND D
			String r = "AND D";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xA3: {
			// AND E
			String r = "AND E";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xA4: {
			// AND H
			String r = "AND H";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xA5: {
			// AND L
			String r = "AND L";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xA6: {
			// AND (HL)
			String r = "AND (HL)";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xA7: {
			// AND A
			String r = "AND A";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xA8: {
			// XOR B
			String r = "XOR B";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xA9: {
			// XOR C
			String r = "XOR C";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xAA: {
			// XOR D
			String r = "XOR D";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xAB: {
			// XOR E
			String r = "XOR E";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xAC: {
			// XOR H
			String r = "XOR H";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xAD: {
			// XOR L
			String r = "XOR L";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xAE: {
			// XOR (HL)
			String r = "XOR (HL)";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xAF: {
			// XOR A
			String r = "XOR A";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xB0: {
			// OR B
			String r = "OR B";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xB1: {
			// OR C
			String r = "OR C";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xB2: {
			// OR D
			String r = "OR D";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xB3: {
			// OR E
			String r = "OR E";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xB4: {
			// OR H
			String r = "OR H";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xB5: {
			// OR L
			String r = "OR L";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xB6: {
			// OR (HL)
			String r = "OR (HL)";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xB7: {
			// OR A
			String r = "OR A";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xB8: {
			// CP B
			String r = "CP B";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xB9: {
			// CP C
			String r = "CP C";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xBA: {
			// CP D
			String r = "CP D";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xBB: {
			// CP E
			String r = "CP E";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xBC: {
			// CP H
			String r = "CP H";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xBD: {
			// CP L
			String r = "CP L";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xBE: {
			// CP (HL)
			String r = "CP (HL)";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xBF: {
			// CP A
			String r = "CP A";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xC0: {
			// RET NZ
			String r = "RET NZ";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xC1: {
			// POP BC
			String r = "POP BC";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xC2: {
			// JP NZ,nn
			String r = "JP NZ," + Integer.toString(this.getWord(addr + 1), 16);
			return new InstructionArray(addr + 3, r);
		}
		// break;
		case 0xC3: {
			// JP nn
			String r = "JP " + Integer.toString(this.getWord(addr + 1), 16);
			return new InstructionArray(addr + 3, r);
		}
		// break;
		case 0xC4: {
			// CALL NZ,nn
			String r = "CALL NZ,"
					+ Integer.toString(this.getWord(addr + 1), 16);
			return new InstructionArray(addr + 3, r);
		}
		// break;
		case 0xC5: {
			// PUSH BC
			String r = "PUSH BC";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xC6: {
			// ADD A,n
			String r = "ADD A," + Integer.toString(this.ram[addr + 1], 16);
			return new InstructionArray(addr + 2, r);
		}
		// break;
		case 0xC7: {
			// RST 0
			String r = "RST 0";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xC8: {
			// RET Z
			String r = "RET Z";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xC9: {
			// // RET nn
			// String r = "RET " + this.getWord(addr+1).toString(16);
			// return new InstructionArray(addr+3, r);
			// RET
			String r = "RET";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xCA: {
			// JP Z,nn
			String r = "JP Z," + Integer.toString(this.getWord(addr + 1), 16);
			return new InstructionArray(addr + 3, r);
		}
		// break;
		case 0xCC: {
			// CALL Z,nn
			String r = "CALL Z," + Integer.toString(this.getWord(addr + 1), 16);
			return new InstructionArray(addr + 3, r);
		}
		// break;
		case 0xCD: {
			// CALL nn
			String r = "CALL " + Integer.toString(this.getWord(addr + 1), 16);
			return new InstructionArray(addr + 3, r);
		}
		// break;
		case 0xCE: {
			// ADC A,n
			String r = "ADC A," + Integer.toString(this.ram[addr + 1], 16);
			return new InstructionArray(addr + 2, r);
		}
		// break;
		case 0xCF: {
			// RST 8
			String r = "RST 8";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xD0: {
			// RET NC
			String r = "RET NC";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xD1: {
			// POP DE
			String r = "POP DE";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xD2: {
			// JP NC,nn
			String r = "JP NC," + Integer.toString(this.getWord(addr + 1), 16);
			return new InstructionArray(addr + 3, r);
		}
		// break;
		case 0xD3: {
			// OUT (n),A
			String r = "OUT (" + Integer.toString(this.ram[addr + 1], 16)
					+ "),A";
			return new InstructionArray(addr + 2, r);
		}
		// break;
		case 0xD4: {
			// CALL NC,nn
			String r = "CALL NC,"
					+ Integer.toString(this.getWord(addr + 1), 16);
			return new InstructionArray(addr + 3, r);
		}
		// break;
		case 0xD5: {
			// PUSH DE
			String r = "PUSH DE";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xD6: {
			// SUB n
			String r = "SUB " + Integer.toString(this.ram[addr + 1], 16);
			return new InstructionArray(addr + 2, r);
		}
		// break;
		case 0xD7: {
			// RST 10H
			String r = "RST 10H";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xD8: {
			// RET C
			String r = "RET C";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xDA: {
			// JP C,nn
			String r = "JP C," + Integer.toString(this.getWord(addr + 1), 16);
			return new InstructionArray(addr + 3, r);
		}
		// break;
		case 0xDB: {
			// IN A,(n)
			String r = "IN A,(" + Integer.toString(this.ram[addr + 1], 16)
					+ ")";
			return new InstructionArray(addr + 2, r);
		}
		// break;
		case 0xDC: {
			// CALL C,nn
			String r = "CALL C," + Integer.toString(this.getWord(addr + 1), 16);
			return new InstructionArray(addr + 3, r);
		}
		// break;
		case 0xDE: {
			// SBC A,n
			String r = "SBC A," + Integer.toString(this.ram[addr + 1], 16);
			return new InstructionArray(addr + 2, r);
		}
		// break;
		case 0xDF: {
			// RST 18H
			String r = "RST 18H";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xE0: {
			// RET PO
			String r = "RET PO";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xE1: {
			// POP HL
			String r = "POP HL";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xE2: {
			// JP PO,nn
			String r = "JP PO," + Integer.toString(this.getWord(addr + 1), 16);
			return new InstructionArray(addr + 3, r);
		}
		// break;
		case 0xE3: {
			// EX (SP),HL ;
			String r = "EX (SP),HL";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xE4: {
			// CALL PO,nn
			String r = "CALL PO,"
					+ Integer.toString(this.getWord(addr + 1), 16);
			return new InstructionArray(addr + 3, r);
		}
		// break;
		case 0xE5: {
			// PUSH HL
			String r = "PUSH HL";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xE6: {
			// AND n
			String r = "AND " + Integer.toString(this.ram[addr + 1], 16);
			return new InstructionArray(addr + 2, r);
		}
		// break;
		case 0xE7: {
			// RST 20H
			String r = "RST 20H";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xE8: {
			// RET PE
			String r = "RET PE";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xE9: {
			// JP (HL)
			String r = "JMP (HL)";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xEA: {
			// JP PE,nn
			String r = "JP PE," + Integer.toString(this.getWord(addr + 1), 16);
			return new InstructionArray(addr + 3, r);
		}
		// break;
		case 0xEB: {
			// EX DE,HL
			String r = "EX DE,HL";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xEC: {
			// CALL PE,nn
			String r = "CALL PE,nn"
					+ Integer.toString(this.getWord(addr + 1), 16);
			return new InstructionArray(addr + 3, r);
		}
		// break;
		case 0xEE: {
			// XOR n
			String r = "XOR " + Integer.toString(this.ram[addr + 1], 16);
			return new InstructionArray(addr + 2, r);
		}
		// break;
		case 0xEF: {
			// RST 28H
			String r = "RST 28H";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xF0: {
			// RET P
			String r = "RET P";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xF1: {
			// POP AF
			String r = "POP AF";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xF2: {
			// JP P,nn
			String r = "JP P," + Integer.toString(this.getWord(addr + 1), 16);
			return new InstructionArray(addr + 3, r);
		}
		// break;
		case 0xF3: {
			// DI
			String r = "DI";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xF4: {
			// CALL P,nn
			String r = "CALL P,nn"
					+ Integer.toString(this.getWord(addr + 1), 16);
			return new InstructionArray(addr + 3, r);
		}
		// break;
		case 0xF5: {
			// PUSH AF
			String r = "PUSH AF";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xF6: {
			// OR n
			String r = "OR " + Integer.toString(this.ram[addr + 1], 16);
			return new InstructionArray(addr + 2, r);
		}
		// break;
		case 0xF7: {
			// RST 30H
			String r = "RST 30H";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xF8: {
			// RET M
			String r = "RET M";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xF9: {
			// LD SP,HL
			String r = "LD SP,HL";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xFA: {
			// JP M,nn
			String r = "JP M," + Integer.toString(this.getWord(addr + 1), 16);
			return new InstructionArray(addr + 3, r);
		}
		// break;
		case 0xFB: {
			// EI
			String r = "EI";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		case 0xFC: {
			// CALL M,nn
			String r = "CALL M," + Integer.toString(this.getWord(addr + 1), 16);
			return new InstructionArray(addr + 3, r);
		}
		// break;
		case 0xFE: {
			// CP n
			String r = "CP " + Integer.toString(this.ram[addr + 1], 16);
			return new InstructionArray(addr + 2, r);
		}
		// break;
		case 0xFF: {
			// RST 38H
			String r = "RST 38H";
			return new InstructionArray(addr + 1, r);
		}
		// break;
		default: {
			// illegal
			String r = "ILLEGAL";
			return new InstructionArray(addr + 1, r);
		}
		// break;

		}
	}

	public InstructionArray disassemble1(int addr) {
		StringBuffer r = new StringBuffer();
		InstructionArray d = this.disassembleInstruction(addr);
		r.append(Memio.pad(Integer.toString(addr, 16), 4));
		r.append(": ");
		int j;
		for (j = 0; j < d.value - addr; j++)
			r.append(Memio.pad(Integer.toString(this.ram[addr + j], 16), 2));
		while (j++ < 3)
			r.append("  ");
		r.append(" ");
		r.append(d.str);
		return new InstructionArray(d.value, r.toString());
	}

	public InstructionArray disassemble(int addr) {
		StringBuffer r = new StringBuffer();
		for (int i = 0; i < 16; ++i) {
			InstructionArray l = this.disassemble1(addr);
			r.append(l.str);
			r.append("\r\n");
			addr = l.value;
		}
		return new InstructionArray(r.toString(), addr);
	}

	public String setRegisters(String[] r) {
		String s = "";
		for (int i = 1; i < r.length; i += 2) {
			String reg = r[i].toLowerCase();
			int n = Integer.parseInt(r[i + 1], 16);
			// s += " " + reg +"="+ n;
			if ("a".equals(reg)) {
				this.a = n & 0xFF;
				// break;
			} else if ("b".equals(reg)) {
				this.b = n & 0xFF;
				// break;
			} else if ("c".equals(reg)) {
				this.c = n & 0xFF;
				// break;
			} else if ("d".equals(reg)) {
				this.d = n & 0xFF;
				// break;
			} else if ("e".equals(reg)) {
				this.e = n & 0xFF;
				// break;
			} else if ("h".equals(reg)) {
				this.h = n & 0xFF;
				// break;
			} else if ("l".equals(reg)) {
				this.l = n & 0xFF;
				// break;
			} else if ("f".equals(reg)) {
				this.f = n & 0xFF;
				// break;
			} else if ("fc".equals(reg)) {
				if ((n & 1) != 0) {
					this.set(CARRY);
				} else {
					this.clear(CARRY);
				}
				// break;
			} else if ("fp".equals(reg)) {
				if ((n & 1) != 0) {
					this.set(PARITY);
				} else {
					this.clear(PARITY);
				}
				// break;
			} else if ("fh".equals(reg)) {
				if ((n & 1) != 0) {
					this.set(HALFCARRY);
				} else {
					this.clear(HALFCARRY);
				}
				// break;
			} else if ("fi".equals(reg)) {
				if ((n & 1) != 0) {
					this.set(INTERRUPT);
				} else {
					this.clear(INTERRUPT);
				}
				// break;
			} else if ("fz".equals(reg)) {
				if ((n & 1) != 0) {
					this.set(ZERO);
				} else {
					this.clear(ZERO);
				}
				// break;
			} else if ("fs".equals(reg)) {
				if ((n & 1) != 0) {
					this.set(SIGN);
				} else {
					this.clear(SIGN);
				}
				// break;
			} else if ("af".equals(reg)) {
				this.AF(n);
				// break;
			} else if ("bc".equals(reg)) {
				this.BC(n);
				// break;
			} else if ("de".equals(reg)) {
				this.DE(n);
				// break;
			} else if ("hl".equals(reg)) {
				this.HL(n);
				// break;
			} else if ("sp".equals(reg)) {
				this.sp = n & 0xFFFF;
				// break;
			} else if ("pc".equals(reg)) {
				this.pc = n & 0xFFFF;
				// break;
			} else {
				s += " unknown register " + reg;
			}
		}
		if (s != null)
			s += "\r\n";
		return s;
	};

	// vim: set shiftwidth=2 :

}
