rasm2 -a i8080 -dBf basic.bin -O basic.asm.txt
rasm2 -a i8080 -dBf basic2.bin -O basic2.asm.txt

