//gcc -o basic basic.c

#include <stdio.h>
#include "basic.h"

//const unsigned char ROM[2048] = {

int main() {
	FILE *fp = fopen("basic.bin", "wb+");
	fwrite(ROM, 1, sizeof(ROM), fp);
	fclose(fp);
	return 0;
}
