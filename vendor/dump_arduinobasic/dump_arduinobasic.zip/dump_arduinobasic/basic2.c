//gcc -o basic2 basic2.c

#include <stdio.h>
#include "basic2.h"

//const unsigned char ROM[2048] = {

int main() {
	FILE *fp = fopen("basic2.bin", "wb+");
	fwrite(ROM, 1, sizeof(ROM), fp);
	fclose(fp);
	return 0;
}
