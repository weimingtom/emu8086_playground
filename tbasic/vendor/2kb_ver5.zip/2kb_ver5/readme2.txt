http://ref.x86asm.net/geek.html#xD6

SALC	AL
Set AL If Carry
