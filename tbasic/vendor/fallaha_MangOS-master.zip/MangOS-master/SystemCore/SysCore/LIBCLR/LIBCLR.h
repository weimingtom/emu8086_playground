// LIBCLR.h

#pragma once

using namespace System;

namespace LIBCLR {

	public ref class Class1
	{
		// TODO: Add your methods for this class here.
	};
}
