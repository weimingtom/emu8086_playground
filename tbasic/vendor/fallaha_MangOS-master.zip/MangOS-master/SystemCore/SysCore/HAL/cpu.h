#ifndef _CPU_H_INCLUDE
#define _CPU_H_INCLUDE

void cpu_initialize();
void cpu_shutdown();


#endif /*_CPU_H_INCLUDE*/